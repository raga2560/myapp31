'use strict';

angular.module('mean.ggexpress')
.factory('Ggexpress', [
  function() {
    return {
      name: 'ggexpress'
    };
  }
])
;
