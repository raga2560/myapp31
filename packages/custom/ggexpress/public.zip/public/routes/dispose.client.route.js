'use strict';

angular.module('mean.ggexpress').config(['$stateProvider',
  function($stateProvider) {
    $stateProvider.state('ggexpress example page', {
      url: '/ggexpress/example',
      templateUrl: 'ggexpress/views/index.html'
    })
  }]);

	