'use strict';

/* jshint -W098 */
angular.module('mean.ggexpress')
.controller('GgexpressController', ['$scope', 'Global', 'Ggexpress',
  function($scope, Global, Ggexpress) {
    $scope.global = Global;
    $scope.package = {
      name: 'ggexpress'
    };
  }
]);


