'use strict';

angular.module('mean.article3').config(['$stateProvider',
  function($stateProvider) {
    $stateProvider.state('article3 example page', {
      url: '/article3/example',
      templateUrl: 'article3/views/index.html'
    })
	.state('dispose', {
      url: '/dispose',
      templateUrl: 'article3/views/index.html'
    })
	.state('dispose.objecttype', {
            url: "/objecttype",
			views: {
                "view21": {
                    
					templateUrl: "article3/views/objecttype_create.html",
					 controller: 'ObjecttypeController'
					 
					
                }
			 }
			
            
        })
		.state('dispose.objecttypelist', {
            url: "/objecttypelist",
			views: {
                "view21": {
                    
					templateUrl: "article3/views/list-objecttype.client.view.html",
					 controller: 'ObjecttypeController'
					 
					
                }
			 }
			
            
        })
		.state('dispose.viewobjecttype', {
            url: "/objecttype/:objecttypeId",
			views: {
                "view21": {
                    
					templateUrl: "article3/views/view-objecttype.client.view.html",
					 controller: 'ObjecttypeController'
					 
					
                }
			 }
			
            
        })
		.state('dispose.editobjecttype', {
            url: "/objecttype/:objecttypeId/edit",
			views: {
                "view21": {
                    
					templateUrl: "article3/views/edit-objecttype.client.view.html",
					 controller: 'ObjecttypeController'
					 
					
                }
			 }
			
            
        })
		
	
	
	;
  }
]);
