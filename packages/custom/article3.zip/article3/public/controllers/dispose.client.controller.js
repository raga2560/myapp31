'use strict';

/* jshint -W098 */
angular.module('mean.article3')
.controller('Article3Controller', ['$scope', 'Global', 'Article3',
  function($scope, Global, Article3) {
    $scope.global = Global;
    $scope.package = {
      name: 'article3'
    };
  }
])
.controller('ObjecttypeController', ['$scope', '$stateParams', '$location', 'Authentication', 'ObjecttypeService',
	function($scope, $stateParams, $location, Authentication, ObjecttypeService) {
		$scope.authentication = Authentication;

		
		// Create new Article
		$scope.create = function() {
			// Create new Article object
			var article = new ObjecttypeService({
				name: this.name,
				typedesc: this.typedesc.split(","),
				giver: this.giver.split(","),
				taker: this.taker.split(","),
				desc: this.desc,
				group: this.group,
				
				
			});

			// Redirect after save
			article.$save(function(response) {
				//$location.path('Objecttype/' + response._id);

				// Clear form fields
				$scope.title = '';
				$scope.content = '';
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};
		$scope.objecttype_submit = function ()
		{
			$scope.create();
		};

		// Remove existing Article
		$scope.remove = function(article) {
			if (article) {
				article.$remove();

				for (var i in $scope.articles) {
					if ($scope.articles[i] === article) {
						$scope.articles.splice(i, 1);
					}
				}
			} else {
				$scope.article.$remove(function() {
					$location.path('objecttype');
				});
			}
		};
		

		$scope.additemtype = function ()
		{
			$scope.newitemtype;
			
		}
		
		// Update existing Article
		$scope.update = function() {
			//	alert('hi1');
				if($scope.article.typedesc.$dirty) {
				$scope.article.typedesc = $scope.article.typedesc.split(",");
				}
			//$scope.article.group = $scope.article.group;
			//alert('hi');
			
			var article = $scope.article;

			article.$update(function() {
			//	$location.path('objecttype/' + article._id);
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		// Find a list of Articles
		$scope.find = function() {
			$scope.articles = ObjecttypeService.query();
		};

		// Find existing Article
		$scope.findOne = function() {
			$scope.article = ObjecttypeService.get({
				objecttypeId: $stateParams.objecttypeId
			});
		};
	}
])

.controller('ObjectController', ['$scope', '$stateParams', '$location', 'Authentication', 'ObjectService',
	function($scope, $stateParams, $location, Authentication, ObjectService) {
		$scope.authentication = Authentication;

		// Create new Article
		$scope.create = function() {
			// Create new Article object
			var article = new ObjectService({
				item: this.item,
				desc: this.desc,
				
				
			});

			// Redirect after save
			article.$save(function(response) {
				$location.path('object/' + response._id);

				// Clear form fields
				$scope.title = '';
				$scope.content = '';
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		// Remove existing Article
		$scope.remove = function(article) {
			if (article) {
				article.$remove();

				for (var i in $scope.articles) {
					if ($scope.articles[i] === article) {
						$scope.articles.splice(i, 1);
					}
				}
			} else {
				$scope.article.$remove(function() {
					$location.path('object');
				});
			}
		};

		// Update existing Article
		$scope.update = function() {
			var article = $scope.article;

			article.$update(function() {
				$location.path('object/' + article._id);
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		// Find a list of Articles
		$scope.find = function() {
			$scope.articles = ObjectService.query();

		};

		// Find existing Article
		$scope.findOne = function() {

			$scope.article = ObjectService.get({
				objectId: $stateParams.objectId
			});
		};
	}
]);
