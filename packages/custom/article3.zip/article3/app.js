'use strict';

/*
 * Defining the Package
 */
var Module = require('meanio').Module;

var Article3 = new Module('article3');

/*
 * All MEAN packages require registration
 * Dependency injection is used to define required modules
 */
Article3.register(function(app, auth, database,  circles, swagger) {

  //We enable routing. By default the Package Object is passed to the routes
  Article3.routes(app, auth, database);

  //We are adding a link to the main menu for all authenticated users
  Article3.menus.add({
    title: 'article3 example page',
    link: 'article3 example page',
    roles: ['authenticated'],
    menu: 'main'
  });
  
  Article3.aggregateAsset('css', 'article3.css');

  /**
    //Uncomment to use. Requires meanio@0.3.7 or above
    // Save settings with callback
    // Use this for saving data from administration pages
    Article3.settings({
        'someSetting': 'some value'
    }, function(err, settings) {
        //you now have the settings object
    });

    // Another save settings example this time with no callback
    // This writes over the last settings.
    Article3.settings({
        'anotherSettings': 'some value'
    });

    // Get settings. Retrieves latest saved settigns
    Article3.settings(function(err, settings) {
        //you now have the settings object
    });
    */

  return Article3;
});
