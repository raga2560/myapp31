'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	errorHandler = require('./errors.server.controller'),
	Article = mongoose.model('Object'),
	Userdata = mongoose.model('Userdata'),
	_ = require('lodash');

module.exports = function(Articles) {

return {


/**
 * Create a article
 */
create : function(req, res) {
	var article = new Article(req.body);
	
		article.user = req.user;
		//article.pref.price = req.query.price;
		article.userdata = req.userdata;
	

	
	article.save(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.json(article);
		}
	}); 
},

/**
 * Show the current article
 */
read : function(req, res) {
	res.json(req.article);
},

/**
 * Update a article
 */
update : function(req, res) {
	var article = req.article;

	article = _.extend(article, req.body);

	article.save(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.json(article);
		}
	});
},

/**
 * Delete an article
 */
delete : function(req, res) {
	var article = req.article;

	article.remove(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.json(article);
		}
	});
},

/**
 * List of Articles
 */
list : function(req, res) {
	if(req.query.user != null)
	{
	console.log(req.query.user)	;
	Article.find({'user': req.user},{'objectdesc':1, 'responses':1}).sort('-created').populate('user', 'displayName').exec(function(err, articles) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.json(articles);
		}
	});
	
	} else {
	
	Article.find().sort('-created').populate('user', 'displayName').exec(function(err, articles) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.json(articles);
		}
	});
	}
},

likinguserupdate : function(req, res, next) {
        "use strict";
	
	   
	   // var item = req.body.item;

       var likinguserdata = req.likinguserdata;
	   console.log('likinguserdata');
	   console.log(likinguserdata);
	
/*	var likinguser = 
	   {'username': req.likinguserdata.displayName, 'userdata': likinguserdata};
		  //console.log("Pattern " + pattern);
		  */
		  
	//console.log(userdata);
	var query = {};
	  query['_id'] = req.likingobject['_id'];
	
	
		
		  
		  
		  Article.update(query,
         {$push: { 'responses' : likinguserdata }},{upsert:true}, function(err, items) { 
		 "use strict";

            if (err) return res.json(null);

			console.log (items);
            console.log("Found " + items.length + " posts");

			 return res.json(items);
			 
			});
		  
	
		
        
  },

  

/**
 * List of Near disposers
 */
near : function(req, res) {
	
	var limit = req.query.limit || 10;

    // get the max distance or set it to 8 kilometers
    var maxDistance = req.query.distance || 8;

    // we need to convert the distance to radians
    // the raduis of Earth is approximately 6371 kilometers
    //maxDistance /= 6371;
	
	maxDistance = 8;

    // get coordinates [ <longitude> , <latitude> ]
    var coords = [];
    coords[0] = req.query.latitude;
    coords[1] = req.query.longitude;

    // find a location
    Article.find({
      loc: {
        $near: coords,
        $maxDistance: maxDistance
      }
    }).limit(limit).exec(function(err, locations) {
      if (err) {
        return res.json(500, err);
      }

      res.status(200).json(locations);
    });
	
	
	/*
	Article.find().sort('-created').populate('user', 'displayName').exec(function(err, articles) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.json(articles);
		}
	}); */
},


	

/**
 * Article middleware
 */
objectByID : function(req, res, next, id) {

	if (!mongoose.Types.ObjectId.isValid(id)) {
		return res.status(400).send({
			message: 'Article is invalid'
		});
	}

	Article.findById(id).populate('user', 'displayName').exec(function(err, article) {
		if (err) return next(err);
		if (!article) {
			return res.status(404).send({
				message: 'Article not found'
			});
		}
		req.article = article;
		next();
	});
},

/**
 * Article authorization middleware
 */
hasAuthorization : function(req, res, next) {
	if (req.article.user.id !== req.user.id) {
		return res.status(403).send({
			message: 'User is not authorized'
		});
	}
	next();
}
};
}
