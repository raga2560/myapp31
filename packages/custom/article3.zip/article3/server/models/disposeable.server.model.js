'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	Schema = mongoose.Schema;

/**
 * Article Schema
 */
var DisposeableSchema = new Schema({
	created: {
		type: Date,
		default: Date.now
	},
	item: {
		type: String,
		default: '',
		trim: true,
		required: 'item cannot be blank'
	},
	loc: {
    type: [Number],  // [<longitude>, <latitude>]
    index: '2d'      // create the geospatial index
    },
	
	desc: {
		type: String,
		default: '',
		trim: true
	},
	userdata: {
		type: Schema.ObjectId,
		ref: 'Userdata'
	},
	user: {
		type: Schema.ObjectId,
		ref: 'User'
	},
	price : {
		type:Number,
		default: 0
	}
});

mongoose.model('Disposeable', DisposeableSchema);
