'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	Schema = mongoose.Schema;

/**
 * Article Schema
 */
var DisposetypeSchema = new Schema({
	
	item: {
		type: String,
		trim: true
		
	},
	desc: {
		type: String,
		default: '',
		trim: true
	},
	reusers: {
    type: [String]
    }
	
});

mongoose.model('Disposetype', DisposetypeSchema);
